const express = require('express');
const router = express.Router();
const Crop = require('../models/crop');
const Scheme = require('../models/scheme');
const User = require('../models/user');

router.post('/register', async (req, res) => {
    const user = new User(req.body);
    await user.save();
    res.status(201).json(user);
});

router.post('/login', async (req, res) => {
    const { username, password } = req.body;
    const admin = await User.findOne({ username, password, role: 'admin' });
    if (admin) {
        res.status(200).json({ message: 'Login successful' });
    } else {
        res.status(401).json({ message: 'Invalid credentials' });
    }
});

router.post('/post-crop', async (req, res) => {
    const crop = new Crop(req.body);
    await crop.save();
    res.status(201).json(crop);
});

router.post('/post-scheme', async (req, res) => {
    const scheme = new Scheme(req.body);
    await scheme.save();
    res.status(201).json(scheme);
});

router.post('/approve-scheme/:id', async (req, res) => {
    try {
        const scheme = await Scheme.findByIdAndUpdate(req.params.id, { approved: true });
        if (scheme) {
            res.status(200).json(scheme);
        } else {
            res.status(404).json({ message: 'Scheme not found' });
        }
    } catch (error) {
        res.status(400).json({ message: 'Invalid Scheme ID' });
    }
});

module.exports = router;
