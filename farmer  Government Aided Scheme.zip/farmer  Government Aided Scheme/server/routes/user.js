const express = require('express');
const router = express.Router();
const User = require('../models/user');
const Scheme = require('../models/scheme');
const Crop = require('../models/crop');

router.post('/register', async (req, res) => {
    const user = new User(req.body);
    await user.save();
    res.status(201).json(user);
});

router.post('/login', async (req, res) => {
    const { username, password } = req.body;
    const user = await User.findOne({ username, password, role: 'user' });
    if (user) {
        res.status(200).json({ message: 'Login successful' });
    } else {
        res.status(401).json({ message: 'Invalid credentials' });
    }
});

router.get('/crops', async (req, res) => {
    const crops = await Crop.find();
    res.status(200).json(crops);
});

router.get('/schemes', async (req, res) => {
    const schemes = await Scheme.find();
    res.status(200).json(schemes);
});

router.post('/apply-scheme/:id', async (req, res) => {
    const scheme = await Scheme.findById(req.params.id);
    if (scheme) {
        scheme.approved = false; // Set approval to false until admin approves
        await scheme.save();
        res.status(200).json(scheme);
    } else {
        res.status(404).json({ message: 'Scheme not found' });
    }
});

module.exports = router;
