const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const schemeSchema = new Schema({
    name: { type: String, required: true },
    details: String,
    approved: { type: Boolean, default: false }
});

module.exports = mongoose.model('Scheme', schemeSchema);
