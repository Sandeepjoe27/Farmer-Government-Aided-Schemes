document.getElementById('register-form').addEventListener('submit', async function(e) {
    e.preventDefault();
    const username = document.getElementById('reg-username').value;
    const password = document.getElementById('reg-password').value;
    
    await fetch('http://localhost:5000/user/register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, password })
    });
    
    alert('User registered successfully');
});

document.getElementById('login-form').addEventListener('submit', async function(e) {
    e.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    const response = await fetch('http://localhost:5000/user/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, password })
    });
    
    const data = await response.json();
    if (response.status === 200) {
        document.getElementById('register-form').style.display = 'none';
        document.getElementById('login-form').style.display = 'none';
        document.getElementById('user-actions').style.display = 'block';
    } else {
        alert(data.message);
    }
});

document.getElementById('view-crops').addEventListener('click', async function() {
    const response = await fetch('http://localhost:5000/user/crops');
    const crops = await response.json();
    
    const cropList = document.getElementById('crop-list');
    cropList.innerHTML = '';
    crops.forEach(crop => {
        const cropItem = document.createElement('div');
        cropItem.textContent = `${crop.name}: ${crop.details}`;
        cropList.appendChild(cropItem);
    });
});

document.getElementById('view-schemes').addEventListener('click', async function() {
    const response = await fetch('http://localhost:5000/user/schemes');
    const schemes = await response.json();
    
    const schemeList = document.getElementById('scheme-list');
    schemeList.innerHTML = '';
    schemes.forEach(scheme => {
        const schemeItem = document.createElement('div');
        schemeItem.textContent = `${scheme.name}: ${scheme.details}`;
        schemeList.appendChild(schemeItem);
    });
});

document.getElementById('apply-schemes').addEventListener('click', async function() {
    const schemeId = prompt('Enter Scheme ID to apply');
    const response = await fetch(`http://localhost:5000/user/apply-scheme/${schemeId}`, {
        method: 'POST'
    });
    
    if (response.status === 200) {
        alert('Applied for scheme successfully');
    } else {
        alert('Failed to apply for scheme');
    }
});
