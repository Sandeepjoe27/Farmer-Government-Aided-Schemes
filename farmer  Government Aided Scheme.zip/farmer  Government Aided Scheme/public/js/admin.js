document.getElementById('login-form').addEventListener('submit', async function(e) {
    e.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    const response = await fetch('http://localhost:5000/admin/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, password })
    });
    
    const data = await response.json();
    if (response.status === 200) {
        document.getElementById('login-form').style.display = 'none';
        document.getElementById('admin-actions').style.display = 'block';
    } else {
        alert(data.message);
    }
});

document.getElementById('post-crop-form').addEventListener('submit', async function(e) {
    e.preventDefault();
    const name = document.getElementById('crop-name').value;
    const details = document.getElementById('crop-details').value;
    
    const response = await fetch('http://localhost:5000/admin/post-crop', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name, details })
    });

    if (response.status === 200) {
        alert('Crop posted successfully');
    } else {
        alert('Failed to post crop');
    }
});

document.getElementById('post-scheme-form').addEventListener('submit', async function(e) {
    e.preventDefault();
    const name = document.getElementById('scheme-name').value;
    const details = document.getElementById('scheme-details').value;
    
    const response = await fetch('http://localhost:5000/admin/post-scheme', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name, details })
    });

    if (response.status === 200) {
        alert('Scheme posted successfully');
    } else {
        alert('Failed to post scheme');
    }
});

document.getElementById('approve-schemes').addEventListener('click', async function() {
    const schemeId = prompt('Enter Scheme ID to approve');
    if (schemeId) {
        const response = await fetch(`http://localhost:5000/admin/approve-scheme/${schemeId}`, {
            method: 'POST'
        });
        
        if (response.status === 200) {
            alert('Scheme approved successfully');
        } else {
            alert('Failed to approve scheme');
        }
    } else {
        alert('Scheme ID is required');
    }
});
